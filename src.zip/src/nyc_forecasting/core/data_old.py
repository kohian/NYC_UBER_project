from pathlib import Path

import numpy as np
import pandas as pd



def ym_to_start_ts(ym: str) -> pd.Timestamp:
    return pd.Timestamp(f"{ym}-01 00:00:00")



def ym_to_exclusive_end_ts(ym: str) -> pd.Timestamp:
    ts = pd.Timestamp(f"{ym}-01 00:00:00")
    return ts + pd.offsets.MonthBegin(1)

def generate_year_month_list(start_ym: str, end_ym: str) -> list[str]:
    """
    Generate inclusive list of YYYY-MM strings from start_ym to end_ym.

    Example:
        generate_year_month_list("2024-01", "2024-03")
        -> ["2024-01", "2024-02", "2024-03"]
    """
    dates = pd.date_range(start=ym_to_start_ts(start_ym), end=ym_to_start_ts(end_ym), freq="MS")
    return [d.strftime("%Y-%m") for d in dates]



def build_monthly_raw_path(base: str, year_month: str) -> str:
    """
    Build raw parquet path for one month.

    Example:
        base = "Data"
        -> "Data/fhvhv_tripdata_2024-01.parquet"

        base = "gs://my-bucket/raw"
        -> "gs://my-bucket/raw/fhvhv_tripdata_2024-01.parquet"
    """
    return f"{base.rstrip('/')}/fhvhv_tripdata_{year_month}.parquet"


def build_processed_path(base: str, year_month: str) -> str:
    """
    Build processed parquet output path for one month.

    Example:
        base = "Data/processed/hourly_demand"
        -> "Data/processed/hourly_demand/hourly_demand_2024-01.parquet"
    """
    return f"{base.rstrip('/')}/hourly_demand_{year_month}.parquet"


def select_files(data_dir: Path, start_ym: str, end_ym: str) -> list[Path]:
    files = sorted(data_dir.glob("hourly_demand_*.parquet"))
    return [f for f in files if start_ym <= f.stem.split("_")[-1] <= end_ym]


def read_csv(path: str) -> pd.DataFrame:
    return pd.read_csv(path)


def read_parquet(path: str, columns=None) -> pd.DataFrame:
    return pd.read_parquet(path, columns=columns, engine="pyarrow")



def write_parquet(df: pd.DataFrame, path: str) -> None:
    df.to_parquet(path, index=False, engine="pyarrow")



def load_monthly_files(files: list[Path]) -> pd.DataFrame:
    if not files:
        raise ValueError("No files selected.")

    dfs = [pd.read_parquet(f, engine="pyarrow") for f in files]
    out = pd.concat(dfs, ignore_index=True)
    out["hour"] = pd.to_datetime(out["hour"])
    out["PULocationID"] = out["PULocationID"].astype("int32")
    out["demand"] = out["demand"].astype("float32")
    return out.sort_values(["hour", "PULocationID"]).reset_index(drop=True)





def get_borough_zone_ids(zone_lookup: pd.DataFrame, borough: str) -> set[int]:
    return set(
        zone_lookup.loc[zone_lookup["Borough"] == borough, "LocationID"]
        .astype("int32")
        .tolist()
    )


def process_monthly_hourly_demand(
    df: pd.DataFrame,
    allowed_zone_ids: set[int],
    year_month: str,
    keep_license: str | None = None,
) -> pd.DataFrame:

    year, month = map(int, year_month.split("-"))

    start = pd.Timestamp(year=year, month=month, day=1)
    if month == 12:
        end = pd.Timestamp(year=year + 1, month=1, day=1)
    else:
        end = pd.Timestamp(year=year, month=month + 1, day=1)

    # Optional license filter
    if keep_license is not None:
        df = df[df["hvfhs_license_num"] == keep_license]

    # Clean
    df = df.dropna(subset=["request_datetime", "PULocationID"])
    df["request_datetime"] = pd.to_datetime(df["request_datetime"])
    df["PULocationID"] = df["PULocationID"].astype("int32")

    # Filter within month
    df = df[(df["request_datetime"] >= start) & (df["request_datetime"] < end)]

    # Zone filter
    df = df[df["PULocationID"].isin(allowed_zone_ids)].copy()

    # Hour bucket
    df["hour"] = df["request_datetime"].dt.floor("h")

    # Aggregate
    hourly = (
        df.groupby(["hour", "PULocationID"])
        .size()
        .reset_index(name="demand")
        .sort_values(["hour", "PULocationID"])
        .reset_index(drop=True)
    )

    return hourly







def make_full_panel(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    all_hours = pd.date_range(start=df["hour"].min(), end=df["hour"].max(), freq="h")
    all_zones = np.sort(df["PULocationID"].unique())

    full_index = pd.MultiIndex.from_product(
        [all_hours, all_zones], names=["hour", "PULocationID"]
    )

    full_df = (
        df.set_index(["hour", "PULocationID"])
        .reindex(full_index, fill_value=0)
        .reset_index()
    )

    wide_df = (
        full_df.pivot(index="hour", columns="PULocationID", values="demand")
        .sort_index()
        .fillna(0)
    )
    # return full_df, wide_df
    return wide_df



def split_wide_by_time(
    wide_df: pd.DataFrame,
    train_start_ts: pd.Timestamp,
    train_end_ts: pd.Timestamp,
    val_start_ts: pd.Timestamp,
    val_end_ts: pd.Timestamp,
    test_start_ts: pd.Timestamp,
    test_end_ts: pd.Timestamp,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    train_wide = wide_df[(wide_df.index >= train_start_ts) & (wide_df.index < train_end_ts)]
    val_wide = wide_df[(wide_df.index >= val_start_ts) & (wide_df.index < val_end_ts)]
    test_wide = wide_df[(wide_df.index >= test_start_ts) & (wide_df.index < test_end_ts)]
    return train_wide, val_wide, test_wide


def make_raw_targets(wide_df, input_len: int) -> np.ndarray:
    return wide_df.to_numpy(dtype=np.float32)[input_len:]



